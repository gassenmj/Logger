#3rd Party Addons

Though we try to pack Logger full of features we can't do everything. The community has really grown around the product and have started to develop their own projects related around Logger.

This page will serve as a simple listing for such projects. To add your project to the list just update this page and make a pull request.


<table>
  <tr>
    <th>Name</th>
    <th>URL</th>
    <th>Description</th>
  </tr>
  <tr>
    <td>Template Generator</td>
    <td><a href="https://github.com/alexnuijten/loggerutil" target="_blank">https://github.com/alexnuijten/loggerutil</a></td>
    <td>Generates logger code for prebuilt procedures. <a href="http://nuijten.blogspot.nl/2015/04/speed-up-development-with-logger.html" target="_blank">Blog article</a>.</td>
  </tr>
</table>